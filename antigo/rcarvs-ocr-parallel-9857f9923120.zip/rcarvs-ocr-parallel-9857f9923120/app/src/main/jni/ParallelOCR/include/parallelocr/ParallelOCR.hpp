//
// Created by Renan Carvalho
//


#ifndef PARALLELOCR_PARALLELOCR_HPP
#define PARALLELOCR_PARALLELOCR_HPP

#include "Coach.hpp"
#include "Letter.hpp"
#include "Image.hpp"


#endif // !PARALLELOCR_PARALLELOCR_HPP
